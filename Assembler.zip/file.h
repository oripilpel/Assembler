#ifndef ASSEMBLER_FILE_H
#define ASSEMBLER_FILE_H

#include "macro.h"
#include <stdio.h>

int macro_expansion(char *filename);

int first_run(char *filename);

#endif
